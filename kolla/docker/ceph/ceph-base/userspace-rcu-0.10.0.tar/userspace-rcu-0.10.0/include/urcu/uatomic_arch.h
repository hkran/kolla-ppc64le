#warning "urcu/uatomic_arch.h is deprecated. Please include urcu/uatomic.h instead."
#include <urcu/uatomic.h>
